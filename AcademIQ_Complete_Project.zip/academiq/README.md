# AcademIQ — AI-Powered Student Dashboard

A full-stack edtech web application featuring an AI tutor (Anthropic Claude), real-time subject progress tracking, task management, and personalized worksheet generation.

> **Note:** This project was developed with the assistance of AI tools (Claude). I reviewed, customized, tested, and structured the implementation.

---

## Features

- **AI Tutor Chat** — Powered by Anthropic Claude API. Reads the student's actual subject progress from the database to give personalized, context-aware responses.
- **Personalized Worksheets** — Generates custom 5-question worksheets per subject and difficulty level using Claude.
- **Subject Progress Tracking** — Visual progress bars per subject; click to update progress inline.
- **Task Manager** — Create, complete, and delete tasks with subject tags and due dates.
- **JWT Authentication** — Secure register and login with bcrypt password hashing.
- **Persistent Chat History** — All AI conversations saved to MySQL and reloaded on next session.

---

## Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Frontend   | React 18, Vite, React Router      |
| Backend    | Node.js, Express                  |
| Database   | MySQL 8                           |
| AI         | Anthropic Claude API              |
| Auth       | JWT (jsonwebtoken) + bcrypt       |
| Deployment | Vercel (frontend) + Railway (API) |

---

## Project Structure

```
academiq/
├── backend/
│   ├── db/
│   │   ├── connection.js     # MySQL connection pool
│   │   └── schema.sql        # Full database schema (5 tables)
│   ├── middleware/
│   │   └── auth.js           # JWT verification middleware
│   ├── routes/
│   │   ├── auth.js           # POST /register, POST /login
│   │   ├── students.js       # GET /dashboard, PATCH /profile
│   │   ├── tasks.js          # Full CRUD for tasks
│   │   ├── subjects.js       # GET + PATCH subject progress
│   │   └── ai.js             # Claude chat, worksheet gen, history
│   ├── .env.example
│   ├── package.json
│   └── server.js
│
├── frontend/
│   ├── src/
│   │   ├── api/client.js         # All fetch calls in one place
│   │   ├── components/
│   │   │   ├── AITutor.jsx       # Claude chat + worksheet modal
│   │   │   ├── Sidebar.jsx       # Navigation sidebar
│   │   │   ├── SubjectProgress.jsx
│   │   │   └── TaskList.jsx
│   │   ├── context/AuthContext.jsx
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Login.jsx
│   │   │   └── Register.jsx
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── .env.example
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
├── .gitignore
└── README.md
```

---

## API Endpoints

| Method | Endpoint                   | Auth | Description                      |
|--------|----------------------------|------|----------------------------------|
| POST   | /api/auth/register         | No   | Create student account           |
| POST   | /api/auth/login            | No   | Login, returns JWT               |
| GET    | /api/students/dashboard    | Yes  | Full dashboard data              |
| PATCH  | /api/students/profile      | Yes  | Update name / learning style     |
| GET    | /api/tasks                 | Yes  | List all tasks                   |
| POST   | /api/tasks                 | Yes  | Create task                      |
| PATCH  | /api/tasks/:id/toggle      | Yes  | Toggle task complete             |
| DELETE | /api/tasks/:id             | Yes  | Delete task                      |
| GET    | /api/subjects              | Yes  | List subjects with progress      |
| PATCH  | /api/subjects/:id          | Yes  | Update subject progress          |
| POST   | /api/ai/chat               | Yes  | Chat with Claude AI tutor        |
| POST   | /api/ai/worksheet          | Yes  | Generate personalized worksheet  |
| GET    | /api/ai/worksheets         | Yes  | List saved worksheets            |
| GET    | /api/ai/chat-history       | Yes  | Get chat history                 |
| GET    | /api/health                | No   | Health check                     |

---

## Setup

### Prerequisites
- Node.js 18+
- MySQL 8
- Anthropic API key (get one at console.anthropic.com)

### 1. Database
```bash
mysql -u root -p < backend/db/schema.sql
```

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env
# Fill in DB credentials, JWT_SECRET, and ANTHROPIC_API_KEY
npm start
```

### 3. Frontend
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:5173 — register an account and start using the dashboard.

---

## Author

**Santhosh Mylagani** — AI Operations & Full-Stack Developer
