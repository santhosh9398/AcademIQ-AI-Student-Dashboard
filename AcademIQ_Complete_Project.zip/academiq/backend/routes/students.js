const express = require('express');
const pool    = require('../db/connection');
const auth    = require('../middleware/auth');
const router  = express.Router();

// GET /api/students/dashboard
router.get('/dashboard', auth, async (req, res) => {
  try {
    const id = req.user.id;

    const [[student]] = await pool.query(
      'SELECT id, name, email, learning_style, created_at FROM students WHERE id = ?', [id]
    );
    if (!student) return res.status(404).json({ error: 'Student not found' });

    const [subjects] = await pool.query(
      'SELECT id, name, progress FROM subjects WHERE student_id = ? ORDER BY name', [id]
    );

    const [tasks] = await pool.query(
      `SELECT id, title, subject, due_date, completed
       FROM tasks WHERE student_id = ?
       ORDER BY completed ASC, due_date ASC LIMIT 10`, [id]
    );

    const [statsRows] = await pool.query(
      `SELECT
         COUNT(*) AS total_tasks,
         SUM(completed = 1) AS completed_tasks
       FROM tasks WHERE student_id = ?`, [id]
    );

    const stats = statsRows[0];
    const avgProgress = subjects.length
      ? Math.round(subjects.reduce((s, sub) => s + sub.progress, 0) / subjects.length)
      : 0;

    res.json({ student, subjects, tasks, stats: { ...stats, avgProgress } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load dashboard' });
  }
});

// PATCH /api/students/profile
router.patch('/profile', auth, async (req, res) => {
  try {
    const { name, learningStyle } = req.body;
    await pool.query(
      'UPDATE students SET name = COALESCE(?, name), learning_style = COALESCE(?, learning_style) WHERE id = ?',
      [name, learningStyle, req.user.id]
    );
    res.json({ message: 'Profile updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

module.exports = router;
