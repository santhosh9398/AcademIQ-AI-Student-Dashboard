const express = require('express');
const pool    = require('../db/connection');
const auth    = require('../middleware/auth');
const router  = express.Router();

// GET /api/subjects
router.get('/', auth, async (req, res) => {
  try {
    const [subjects] = await pool.query(
      'SELECT id, name, progress FROM subjects WHERE student_id = ? ORDER BY name',
      [req.user.id]
    );
    res.json(subjects);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subjects' });
  }
});

// PATCH /api/subjects/:id
router.patch('/:id', auth, async (req, res) => {
  try {
    const { progress } = req.body;
    if (progress === undefined || progress < 0 || progress > 100)
      return res.status(400).json({ error: 'Progress must be 0–100' });

    const [result] = await pool.query(
      'UPDATE subjects SET progress = ? WHERE id = ? AND student_id = ?',
      [progress, req.params.id, req.user.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Subject not found' });
    res.json({ message: 'Progress updated' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update subject' });
  }
});

module.exports = router;
