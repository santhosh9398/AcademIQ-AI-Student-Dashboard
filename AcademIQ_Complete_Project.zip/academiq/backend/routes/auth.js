const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const pool     = require('../db/connection');
const router   = express.Router();

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, learningStyle = 'visual' } = req.body;
    if (!name || !email || !password)
      return res.status(400).json({ error: 'Name, email, and password are required' });

    const [existing] = await pool.query('SELECT id FROM students WHERE email = ?', [email]);
    if (existing.length)
      return res.status(409).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO students (name, email, password, learning_style) VALUES (?,?,?,?)',
      [name, email, hash, learningStyle]
    );

    // Seed default subjects with realistic starting progress
    const defaults = [
      { name: 'Mathematics', progress: 45 },
      { name: 'Science',     progress: 60 },
      { name: 'English',     progress: 70 },
      { name: 'History',     progress: 35 },
    ];
    for (const s of defaults) {
      await pool.query(
        'INSERT INTO subjects (student_id, name, progress) VALUES (?,?,?)',
        [result.insertId, s.name, s.progress]
      );
    }

    res.status(201).json({ message: 'Account created successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during registration' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required' });

    const [rows] = await pool.query('SELECT * FROM students WHERE email = ?', [email]);
    if (!rows.length)
      return res.status(401).json({ error: 'Invalid email or password' });

    const student = rows[0];
    const valid = await bcrypt.compare(password, student.password);
    if (!valid)
      return res.status(401).json({ error: 'Invalid email or password' });

    const token = jwt.sign(
      { id: student.id, name: student.name },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      student: { id: student.id, name: student.name, email: student.email }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error during login' });
  }
});

module.exports = router;
