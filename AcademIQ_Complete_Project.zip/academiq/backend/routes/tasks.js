const express = require('express');
const pool    = require('../db/connection');
const auth    = require('../middleware/auth');
const router  = express.Router();

// GET /api/tasks
router.get('/', auth, async (req, res) => {
  try {
    const [tasks] = await pool.query(
      `SELECT id, title, subject, due_date, completed, created_at
       FROM tasks WHERE student_id = ?
       ORDER BY completed ASC, due_date ASC`,
      [req.user.id]
    );
    res.json(tasks);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch tasks' });
  }
});

// POST /api/tasks
router.post('/', auth, async (req, res) => {
  try {
    const { title, subject, dueDate } = req.body;
    if (!title) return res.status(400).json({ error: 'Title is required' });

    const [result] = await pool.query(
      'INSERT INTO tasks (student_id, title, subject, due_date) VALUES (?,?,?,?)',
      [req.user.id, title, subject || null, dueDate || null]
    );
    res.status(201).json({
      id: result.insertId, title, subject, due_date: dueDate, completed: false
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

// PATCH /api/tasks/:id/toggle
router.patch('/:id/toggle', auth, async (req, res) => {
  try {
    const [result] = await pool.query(
      'UPDATE tasks SET completed = NOT completed WHERE id = ? AND student_id = ?',
      [req.params.id, req.user.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Task not found' });
    res.json({ message: 'Task toggled' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to toggle task' });
  }
});

// DELETE /api/tasks/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    const [result] = await pool.query(
      'DELETE FROM tasks WHERE id = ? AND student_id = ?',
      [req.params.id, req.user.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Task not found' });
    res.json({ message: 'Task deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

module.exports = router;
