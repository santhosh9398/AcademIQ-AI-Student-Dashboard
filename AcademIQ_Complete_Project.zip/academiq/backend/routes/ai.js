const express   = require('express');
const Anthropic  = require('@anthropic-ai/sdk');
const pool      = require('../db/connection');
const auth      = require('../middleware/auth');
const router    = express.Router();
const client    = new Anthropic();

// POST /api/ai/chat
router.post('/chat', auth, async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: 'Message is required' });

    const studentId = req.user.id;

    // Load student context from DB
    const [[student]] = await pool.query(
      'SELECT name, learning_style FROM students WHERE id = ?', [studentId]
    );
    const [subjects] = await pool.query(
      'SELECT name, progress FROM subjects WHERE student_id = ?', [studentId]
    );
    const [tasks] = await pool.query(
      'SELECT title, subject, completed FROM tasks WHERE student_id = ? LIMIT 5', [studentId]
    );

    const context = subjects.map(s => `${s.name}: ${s.progress}%`).join(', ');
    const pendingTasks = tasks.filter(t => !t.completed).map(t => t.title).join(', ');

    // Fetch recent chat history for context
    const [history] = await pool.query(
      `SELECT role, content FROM chat_history
       WHERE student_id = ? ORDER BY created_at DESC LIMIT 6`, [studentId]
    );
    const historyMessages = history.reverse().map(h => ({
      role: h.role, content: h.content
    }));

    const response = await client.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 400,
      system: `You are a friendly, encouraging AI tutor for a student named ${student.name}.
Learning style: ${student.learning_style}.
Subject progress: ${context}.
Pending tasks: ${pendingTasks || 'none'}.
Keep responses concise (2–4 sentences), actionable, and encouraging.
If asked to generate a worksheet, tell them to use the "Generate Worksheet" button instead.`,
      messages: [...historyMessages, { role: 'user', content: message }],
    });

    const reply = response.content[0].text;

    // Save to chat history
    await pool.query(
      'INSERT INTO chat_history (student_id, role, content) VALUES (?,?,?),(?,?,?)',
      [studentId, 'user', message, studentId, 'assistant', reply]
    );

    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'AI chat failed. Check your ANTHROPIC_API_KEY.' });
  }
});

// POST /api/ai/worksheet
router.post('/worksheet', auth, async (req, res) => {
  try {
    const { subject, level = 'intermediate' } = req.body;
    if (!subject) return res.status(400).json({ error: 'Subject is required' });

    const [[student]] = await pool.query(
      'SELECT name FROM students WHERE id = ?', [req.user.id]
    );

    const response = await client.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 800,
      messages: [{
        role: 'user',
        content: `Create a ${level} level ${subject} worksheet for a student named ${student.name}.
Format:
- Title at top
- 5 clearly numbered questions of increasing difficulty
- A blank line after each question for writing answers
- A section at the bottom labeled "ANSWERS:" with brief answers

Keep it clean and student-friendly.`,
      }],
    });

    const content = response.content[0].text;

    // Save worksheet to DB
    await pool.query(
      'INSERT INTO worksheets (student_id, subject, level, content) VALUES (?,?,?,?)',
      [req.user.id, subject, level, content]
    );

    res.json({ worksheet: content });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Worksheet generation failed. Check your ANTHROPIC_API_KEY.' });
  }
});

// GET /api/ai/worksheets — list saved worksheets
router.get('/worksheets', auth, async (req, res) => {
  try {
    const [sheets] = await pool.query(
      'SELECT id, subject, level, created_at FROM worksheets WHERE student_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(sheets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch worksheets' });
  }
});

// GET /api/ai/chat-history
router.get('/chat-history', auth, async (req, res) => {
  try {
    const [history] = await pool.query(
      `SELECT role, content, created_at FROM chat_history
       WHERE student_id = ? ORDER BY created_at ASC LIMIT 50`,
      [req.user.id]
    );
    res.json(history);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch chat history' });
  }
});

module.exports = router;
