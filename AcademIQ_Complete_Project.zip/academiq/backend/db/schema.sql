-- Run this file to set up the database:
-- mysql -u root -p < backend/db/schema.sql

CREATE DATABASE IF NOT EXISTS academiq;
USE academiq;

-- ─── Students ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100)  NOT NULL,
  email          VARCHAR(100)  NOT NULL UNIQUE,
  password       VARCHAR(255)  NOT NULL,
  learning_style VARCHAR(50)   DEFAULT 'visual',
  created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ─── Subjects ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subjects (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT          NOT NULL,
  name       VARCHAR(100) NOT NULL,
  progress   INT          DEFAULT 0,
  updated_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CHECK (progress BETWEEN 0 AND 100)
);

-- ─── Tasks ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT          NOT NULL,
  title      VARCHAR(255) NOT NULL,
  subject    VARCHAR(100),
  due_date   DATE,
  completed  BOOLEAN      DEFAULT FALSE,
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─── Chat History ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chat_history (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT         NOT NULL,
  role       ENUM('user','assistant') NOT NULL,
  content    TEXT        NOT NULL,
  created_at TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─── Worksheets ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS worksheets (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT          NOT NULL,
  subject    VARCHAR(100),
  level      VARCHAR(50),
  content    LONGTEXT,
  created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);
