import { useState, useRef, useEffect } from 'react';
import { chatWithAI, generateWorksheet } from '../api/client.js';

const INITIAL = (name) => [{
  role: 'assistant',
  content: `Hi ${name}! 👋 I'm your AI Tutor powered by Claude. I can see your subject progress and tasks. Ask me anything, or use the quick actions below!`
}];

const QUICK = ['Help me study Math', 'What should I focus on?', 'Give me study tips'];

export default function AITutor({ studentName }) {
  const [messages, setMessages]   = useState(INITIAL(studentName));
  const [input, setInput]         = useState('');
  const [loading, setLoading]     = useState(false);
  const [showWs, setShowWs]       = useState(false);
  const [wsSubject, setWsSubject] = useState('Mathematics');
  const [wsLevel, setWsLevel]     = useState('intermediate');
  const [wsContent, setWsContent] = useState('');
  const [wsLoading, setWsLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const send = async (text) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: msg }]);
    setLoading(true);
    try {
      const data = await chatWithAI(msg);
      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Sorry, I couldn't connect. ${err.message}` }]);
    }
    setLoading(false);
  };

  const genWorksheet = async () => {
    setWsLoading(true); setWsContent('');
    try {
      const data = await generateWorksheet(wsSubject, wsLevel);
      setWsContent(data.worksheet);
    } catch (err) {
      setWsContent('Failed to generate worksheet. ' + err.message);
    }
    setWsLoading(false);
  };

  return (
    <>
      <div className="ai-panel">
        <div className="ai-header">
          <div className="ai-title-row">
            <div className="ai-dot" />
            <div className="ai-title">AI Tutor</div>
          </div>
          <div className="ai-powered">Powered by Claude</div>
          <div className="ai-actions">
            {QUICK.map(q => (
              <div key={q} className="chip" onClick={() => send(q)}>{q}</div>
            ))}
            <div className="chip" style={{ background: '#E6F1FB', color: '#185FA5', borderColor: '#B5D4F4' }}
              onClick={() => setShowWs(true)}>
              📄 Generate worksheet
            </div>
          </div>
        </div>

        <div className="chat-area">
          {messages.map((m, i) => (
            <div key={i} className={`msg ${m.role}`}>
              {m.role === 'assistant' && <div className="msg-sender">AI Tutor</div>}
              <div className="bubble" style={{ whiteSpace: 'pre-wrap' }}>{m.content}</div>
            </div>
          ))}
          {loading && (
            <div className="msg ai">
              <div className="bubble">
                <div className="typing-dots">
                  <span/><span/><span/>
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <div className="chat-input-row">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send()}
            placeholder="Ask anything..."
          />
          <button className="send-btn" onClick={() => send()}>➤</button>
        </div>
      </div>

      {/* Worksheet modal */}
      {showWs && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowWs(false)}>
          <div className="modal-box">
            <h3>📄 Generate worksheet</h3>
            <div className="form-group">
              <label>Subject</label>
              <select value={wsSubject} onChange={e => setWsSubject(e.target.value)}>
                {['Mathematics','Science','English','History'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Difficulty level</label>
              <select value={wsLevel} onChange={e => setWsLevel(e.target.value)}>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
            <button className="btn btn-primary" onClick={genWorksheet} disabled={wsLoading}>
              {wsLoading ? 'Generating...' : 'Generate'}
            </button>

            {wsContent && (
              <>
                <div className="worksheet-content">{wsContent}</div>
                <div className="modal-actions">
                  <button className="btn btn-ghost btn-sm" onClick={() => navigator.clipboard.writeText(wsContent)}>
                    Copy
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={() => setShowWs(false)}>Close</button>
                </div>
              </>
            )}
            {!wsContent && (
              <div className="modal-actions" style={{ marginTop: 12 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowWs(false)}>Cancel</button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
