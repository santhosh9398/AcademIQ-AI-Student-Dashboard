import { useState } from 'react';
import { createTask, toggleTask, deleteTask } from '../api/client.js';

const SUBJECTS = ['Mathematics', 'Science', 'English', 'History'];

function tagClass(subject) {
  return SUBJECTS.includes(subject) ? `task-tag tag-${subject}` : 'task-tag tag-default';
}

export default function TaskList({ tasks, onUpdate }) {
  const [title, setTitle]     = useState('');
  const [subject, setSubject] = useState('Mathematics');
  const [dueDate, setDueDate] = useState('');
  const [adding, setAdding]   = useState(false);

  const add = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    setAdding(true);
    try {
      await createTask({ title, subject, dueDate: dueDate || undefined });
      setTitle(''); setDueDate('');
      onUpdate();
    } catch {}
    setAdding(false);
  };

  const toggle = async (id) => {
    try { await toggleTask(id); onUpdate(); } catch {}
  };

  const remove = async (id) => {
    try { await deleteTask(id); onUpdate(); } catch {}
  };

  return (
    <div className="section">
      <div className="section-header">
        <div className="section-title">Tasks</div>
        <span style={{ fontSize: 11, color: '#5F5E5A' }}>
          {tasks.filter(t => !t.completed).length} pending
        </span>
      </div>

      {tasks.length === 0 && (
        <p style={{ fontSize: 13, color: '#888780', marginBottom: 12 }}>No tasks yet. Add one below!</p>
      )}

      {tasks.map(t => (
        <div key={t.id} className="task-row">
          <div className={`check-box ${t.completed ? 'done' : ''}`} onClick={() => toggle(t.id)}>
            {t.completed ? '✓' : ''}
          </div>
          <div className={`task-text ${t.completed ? 'done' : ''}`}>{t.title}</div>
          {t.subject && <span className={tagClass(t.subject)}>{t.subject}</span>}
          {t.due_date && (
            <span style={{ fontSize: 10, color: '#888780' }}>
              {new Date(t.due_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
            </span>
          )}
          <button className="task-delete" onClick={() => remove(t.id)} title="Delete">✕</button>
        </div>
      ))}

      <form onSubmit={add} className="add-task-form">
        <input
          type="text" value={title} onChange={e => setTitle(e.target.value)}
          placeholder="New task..." />
        <select value={subject} onChange={e => setSubject(e.target.value)}>
          {SUBJECTS.map(s => <option key={s}>{s}</option>)}
        </select>
        <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
        <button className="btn btn-primary btn-sm" type="submit" disabled={adding}>
          {adding ? '...' : '+ Add'}
        </button>
      </form>
    </div>
  );
}
