import { useState } from 'react';
import { updateSubject } from '../api/client.js';

const SUBJECT_META = {
  Mathematics: { icon: '📐', color: '#185FA5', bg: '#E6F1FB' },
  Science:     { icon: '🔬', color: '#0F6E56', bg: '#E1F5EE' },
  English:     { icon: '📖', color: '#534AB7', bg: '#EEEDFE' },
  History:     { icon: '🌍', color: '#854F0B', bg: '#FAEEDA' },
};

function getMeta(name) {
  return SUBJECT_META[name] || { icon: '📘', color: '#888780', bg: '#F1EFE8' };
}

export default function SubjectProgress({ subjects, onUpdate }) {
  const [editing, setEditing]   = useState(null);
  const [newPct, setNewPct]     = useState(0);
  const [saving, setSaving]     = useState(false);

  const startEdit = (s) => { setEditing(s.id); setNewPct(s.progress); };

  const save = async (id) => {
    setSaving(true);
    try {
      await updateSubject(id, newPct);
      onUpdate();
    } catch {}
    setSaving(false);
    setEditing(null);
  };

  return (
    <div className="section">
      <div className="section-header">
        <div className="section-title">Subject progress</div>
        <span style={{fontSize:11, color:'#5F5E5A'}}>Click % to update</span>
      </div>

      {subjects.map(s => {
        const meta = getMeta(s.name);
        return (
          <div key={s.id} className="subject-row">
            <div className="subject-icon" style={{ background: meta.bg }}>{meta.icon}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="subject-name">{s.name}</div>
            </div>
            <div className="progress-track">
              <div className="progress-fill" style={{ width: `${s.progress}%`, background: meta.color }} />
            </div>
            {editing === s.id ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <input
                  type="number" min="0" max="100" value={newPct}
                  onChange={e => setNewPct(Number(e.target.value))}
                  style={{ width: 52, padding: '3px 6px', border: '1px solid #D3D1C7', borderRadius: 6, fontSize: 12 }}
                />
                <button className="btn btn-sm btn-primary" onClick={() => save(s.id)} disabled={saving}>✓</button>
                <button className="btn btn-sm btn-ghost" onClick={() => setEditing(null)}>✕</button>
              </div>
            ) : (
              <div className="pct" style={{ cursor: 'pointer', color: meta.color, fontWeight: 500 }}
                onClick={() => startEdit(s)}>
                {s.progress}%
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
