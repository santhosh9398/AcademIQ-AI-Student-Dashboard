import { useAuth } from '../context/AuthContext.jsx';
import { useNavigate } from 'react-router-dom';

const NAV = [
  { icon: '📊', label: 'Dashboard' },
  { icon: '📚', label: 'My courses' },
  { icon: '📅', label: 'Schedule' },
  { icon: '📈', label: 'Analytics' },
];
const TOOLS = [
  { icon: '📄', label: 'Worksheets' },
  { icon: '💡', label: 'AI tutor' },
  { icon: '⚙️', label: 'Settings' },
];

export default function Sidebar({ student, initials }) {
  const { signOut } = useAuth();
  const navigate    = useNavigate();

  return (
    <nav className="sidebar">
      <div className="sidebar-logo">
        <span>A</span> AcademIQ
      </div>

      {NAV.map((item, i) => (
        <div key={item.label} className={`nav-item ${i === 0 ? 'active' : ''}`}>
          <span className="nav-icon">{item.icon}</span> {item.label}
        </div>
      ))}

      <div className="nav-section">Tools</div>
      {TOOLS.map(item => (
        <div key={item.label} className="nav-item">
          <span className="nav-icon">{item.icon}</span> {item.label}
        </div>
      ))}

      <div className="sidebar-footer">
        <div className="user-chip">
          <div className="avatar">{initials}</div>
          <div>
            <div className="user-name">{student.name.split(' ')[0]}</div>
            <div className="user-role">Student</div>
          </div>
        </div>
        <button
          className="btn btn-ghost btn-sm"
          style={{ width: '100%', marginTop: 8 }}
          onClick={() => { signOut(); navigate('/login'); }}
        >
          Sign out
        </button>
      </div>
    </nav>
  );
}
