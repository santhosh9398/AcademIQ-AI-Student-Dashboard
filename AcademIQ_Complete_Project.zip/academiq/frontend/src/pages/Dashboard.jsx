import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { getDashboard } from '../api/client.js';
import Sidebar          from '../components/Sidebar.jsx';
import SubjectProgress  from '../components/SubjectProgress.jsx';
import TaskList         from '../components/TaskList.jsx';
import AITutor          from '../components/AITutor.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  const fetchData = async () => {
    try {
      const d = await getDashboard();
      setData(d);
    } catch (err) {
      setError('Failed to load dashboard. Is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  if (loading) return <div className="loading-screen">Loading dashboard...</div>;
  if (error)   return <div className="loading-screen" style={{color:'#A32D2D'}}>{error}</div>;

  const { student, subjects, tasks, stats } = data;
  const initials = student.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  const completedToday = tasks.filter(t => t.completed).length;
  const dueToday = tasks.filter(t => !t.completed).length;

  return (
    <div className="app-shell">
      <Sidebar student={student} initials={initials} />

      <main className="main-content">
        <div className="page-header">
          <div className="page-title">
            Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, {student.name.split(' ')[0]} 👋
          </div>
          <div className="page-subtitle">
            {dueToday > 0 ? `You have ${dueToday} task${dueToday > 1 ? 's' : ''} pending` : 'All tasks done for today! Great work.'}
          </div>
        </div>

        <div className="stats-row">
          <div className="stat-card">
            <div className="stat-label">Avg. progress</div>
            <div className="stat-value">{stats.avgProgress}%</div>
            <div className="stat-delta">↑ Across all subjects</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Tasks done</div>
            <div className="stat-value">{stats.completed_tasks ?? 0} / {stats.total_tasks ?? 0}</div>
            <div className="stat-delta">
              {stats.total_tasks > 0
                ? `${Math.round((stats.completed_tasks / stats.total_tasks) * 100)}% completion rate`
                : 'No tasks yet'}
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Learning style</div>
            <div className="stat-value" style={{fontSize:16, textTransform:'capitalize'}}>
              {student.learning_style}
            </div>
            <div className="stat-delta">↑ Personalized AI responses</div>
          </div>
        </div>

        <SubjectProgress subjects={subjects} onUpdate={fetchData} />
        <TaskList tasks={tasks} onUpdate={fetchData} />
      </main>

      <AITutor studentName={student.name.split(' ')[0]} />
    </div>
  );
}
