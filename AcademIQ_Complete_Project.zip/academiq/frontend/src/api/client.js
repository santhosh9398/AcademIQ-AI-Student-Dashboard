const BASE = import.meta.env.VITE_API_URL || '/api';

function authHeaders() {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: authHeaders(),
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ── Auth ─────────────────────────────────────────────────────────────────────
export const login = (email, password) =>
  request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });

export const register = (name, email, password, learningStyle) =>
  request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name, email, password, learningStyle }),
  });

// ── Dashboard ────────────────────────────────────────────────────────────────
export const getDashboard = () => request('/students/dashboard');

// ── Tasks ─────────────────────────────────────────────────────────────────────
export const getTasks    = ()         => request('/tasks');
export const createTask  = (data)     => request('/tasks', { method: 'POST', body: JSON.stringify(data) });
export const toggleTask  = (id)       => request(`/tasks/${id}/toggle`, { method: 'PATCH' });
export const deleteTask  = (id)       => request(`/tasks/${id}`, { method: 'DELETE' });

// ── Subjects ─────────────────────────────────────────────────────────────────
export const updateSubject = (id, progress) =>
  request(`/subjects/${id}`, { method: 'PATCH', body: JSON.stringify({ progress }) });

// ── AI ────────────────────────────────────────────────────────────────────────
export const chatWithAI       = (message)          => request('/ai/chat', { method: 'POST', body: JSON.stringify({ message }) });
export const generateWorksheet = (subject, level)  => request('/ai/worksheet', { method: 'POST', body: JSON.stringify({ subject, level }) });
export const getChatHistory   = ()                 => request('/ai/chat-history');
export const getWorksheets    = ()                 => request('/ai/worksheets');
